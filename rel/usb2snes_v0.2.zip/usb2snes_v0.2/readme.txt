This is an alpha version of usb2snes using a modified version of the sd2snes FW 0.1.7e.

*** PLEASE BACKUP YOUR SD CARD BEFORE TRYING THIS ***

1) 0.1.7e-usb0<N> Firmware update.
a) Copy the contents of the sd2snes/ folder to your SD card's sd2snes folder.
b) Boot up the sd2snes with the SD card installed.
c) Check the firmware version ([X]->System Information [A]->Firmware version).  It should read 0.1.7e-usb0.
d) Remove the firmware image from the sd2snes directory on the SD card: sd2snes/firmware.img.  This isn't necessary, but generally a good idea.

If you have problems you should try the unmodified 0.1.7e FW available at: https://sd2snes.de/blog/downloads.  It doesn't have USB support, but testing it will help eliminate the USB changes as a cause of the problem.

2) Plug in the sd2snes usb port to your windows machine.
a) If windows7, update your driver in Device Manager to the driver in win7_driver.  If windows10 the correct driver should already be installed.
b) Check if the sd2snes is recognized correctly.  In Device Manager check 'Ports (COM & LPT)' for your sd2snes.  In win7 it should say sd2snes.  In win10 it may have a generic name.

You should hear the usb connection sound if it's properly connected and recognized.  Make sure there are no unrecognized/errored devices in 'Universal Serial Bus controllers' section.  If there are, make sure you install the driver if you're on win7.

^^^^^^^^^^^^^ Only needs to be done once.

3) Try the usb2snes tool.
This program shows the directory listing on your SD card using the usb connection.  It attempts to pick the correct COM port automatically on startup, but you may have to click the green refresh icon and select your sd2snes from the drop down menu.  If the sd2snes doesn't show up here and step (2) was successful then there is probably a bug in the program.  Also make sure nothing else is trying to use the sd2snes usb port like the zelda HUD.
- upload lets you upload roms to the current directory.
- boot lets you start up a snes rom.  some roms (msu?) don't seem to work, yet.
- other features have been added included: upload (slow), delete, rename

The program should work in the sd2snes menu or in a game.

4) Try the zelda HUD.
a) Right click on the title bar and select AutoUpdate USB.  Select the sd2snes COM port.  Make sure nothing else is using the sd2snes USB connection.  If you're not in the game it may show random items collected.  Ignore this and clear the selected items when you start the game.
b) Play the game and watch most (but not all) items get selected.
c) Disconnect the auto update by selecting AutoUpdate USB a second time or closing the program.

The included zelda HUD for items in the alttp randomizer is a little old and not complete, but it works as a testing tool.  It reads SRAM from the running game and auto updates the item status.  Several of the items are not supported so don't be surprised if some don't light up correctly.  It may not work with the latest randomizer as I haven't tested it.  

-------------

Thanks to saturnu for the usb firmware source.  A lot of it has been rewritten, but the CDC/block transfer code still remains and other changes used the original code as reference.

Thanks to the zelda HUD person.  It was the first thing I tested with the usb2snes FW changes before writing the usb2snes tool.
